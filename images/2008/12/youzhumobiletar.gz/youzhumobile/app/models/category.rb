class Category < ActiveRecord::Base
  validates_presence_of :categ_level, :node_id, :name_en

end
