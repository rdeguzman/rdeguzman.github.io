//
//  RouteMeSampleMapDBOfflineAppDelegate.m
//  RouteMeSampleMapDBOffline
//
//  Created by rupert on 22/12/09.
//  Copyright __MyCompanyName__ 2009. All rights reserved.
//

#import "RouteMeSampleMapDBOfflineAppDelegate.h"
#import "RouteMeSampleMapDBOfflineViewController.h"

#define kDatabaseName @"test.db"

@interface RouteMeSampleMapDBOfflineAppDelegate(private)
- (void)createEditableCopyOfDatabaseIfNeeded;
@end

@implementation RouteMeSampleMapDBOfflineAppDelegate

@synthesize window;
@synthesize viewController;

- (void)applicationDidFinishLaunching:(UIApplication *)application {    
    [self createEditableCopyOfDatabaseIfNeeded];
	
    // Override point for customization after app launch    
    [window addSubview:viewController.view];
    [window makeKeyAndVisible];
}

- (void)dealloc {
    [viewController release];
    [window release];
    [super dealloc];
}

- (NSString *)dbPath{
	NSArray *paths = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
    NSString *documentsDirectory = [paths objectAtIndex:0];
    return [documentsDirectory stringByAppendingPathComponent:kDatabaseName];
}

// Creates a writable copy of the bundled default database in the application Documents directory.
- (void)createEditableCopyOfDatabaseIfNeeded {
    // First, test for existence.
    BOOL success;
    NSFileManager *fileManager = [NSFileManager defaultManager];
    NSError *error;
	
	NSString *writableDBPath = [self dbPath];
    
	success = [fileManager fileExistsAtPath:writableDBPath];
	
    if (success){
		NSLog(@"writing to %@", writableDBPath);
		return;
	} 
	else{
		[fileManager removeItemAtPath:writableDBPath error:&error]; 
	}
	
    // The writable database does not exist, so copy the default to the appropriate location.
    NSString *defaultDBPath = [[[NSBundle mainBundle] resourcePath] stringByAppendingPathComponent:kDatabaseName];
    success = [fileManager copyItemAtPath:defaultDBPath toPath:writableDBPath error:&error];
    if (!success) {
        NSLog(@"Failed to create writable database file with message '%@'.", [error localizedDescription]);
    }
}


@end
