//
//  DrawMapAppDelegate.h
//  DrawMap
//
//  Created by rupert on 9/08/10.
//  Copyright 2RMobile 2010. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface DrawMapAppDelegate : NSObject <UIApplicationDelegate> {
    UIWindow *window;
	UINavigationController *navigationController;
}

@property (nonatomic, retain) IBOutlet UIWindow *window;

@end

