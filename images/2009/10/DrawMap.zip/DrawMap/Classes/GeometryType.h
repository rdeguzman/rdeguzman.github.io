/*
 *  GeometryType.h
 *  DrawMap
 *
 *  Created by rupert on 2/10/09.
 *  Copyright 2009 __MyCompanyName__. All rights reserved.
 *
 */

typedef enum {
	kGeometryTypePoint	 = 1,
	kGeometryTypeLine	 = 2,
	kGeometryTypePolygon = 3
} GeometryType;
