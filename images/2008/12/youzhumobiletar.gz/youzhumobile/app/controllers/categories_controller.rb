class CategoriesController < ApplicationController
  def index
    @categories = Category.find( :all , :order => 'order_id')
  end
  
  def new
    @category = Category.new
  end
  
  def show
    @category = Category.find(params[:id])
  end
  
  def edit
    @category = Category.find(params[:id])
  end
  
  def destroy
    @category = Category.find(params[:id])
    name = @category.name_en
    @category.destroy
    
    flash[:notice] = 'You have successfully deleted ' + name
    redirect_to categories_path
  end  

  def create
    @category = Category.new(params[:category])
    category_count = Category.count
    @category.order_id = category_count + 1
    
    if @category.save #if true
      flash[:notice] = 'Category added successfully'
      redirect_to admin_categories_path
    else
      render :action => 'new'
    end
  end
    
  def update
    @category = Category.find(params[:id])
    if @category.update_attributes(params[:category])
      flash[:notice] = 'Category was successfully updated.'
      redirect_to :action => 'index'
    else                     
      render :action => 'edit'
    end
  
  end
  
  #need to refactor move_up and move_down to one method and pass id, movement
  def move_up
    @category_current = Category.find(params[:id])
    @min_category = Category.find(:first, :order => 'order_id')
    
    if @category_current.order_id > @min_category.order_id
      condition_sql = "order_id < " + @category_current.order_id.to_s
      find_order_id = Category.find(:first, :conditions => condition_sql, :order => 'order_id DESC').order_id
      
      move(find_order_id, @category_current)
    end
    redirect_to :action => 'index'
  end  
  
  def move_down
    @category_current = Category.find(params[:id])
    @max_category = Category.find(:first, :order => 'order_id DESC')

    if @category_current.order_id < @max_category.order_id
      condition_sql = "order_id > " + @category_current.order_id.to_s
      find_order_id = Category.find(:first, :conditions => condition_sql, :order => 'order_id ASC').order_id
      
      move(find_order_id, @category_current)
    end
    redirect_to :action => 'index'
  end
  
  private
    def move(find_order_id, category_current)
      category_old = Category.find_by_order_id(find_order_id)

      category_old.order_id = @category_current.order_id
      category_current.order_id = find_order_id
      
      category_old.save
      category_current.save      
    end

end
