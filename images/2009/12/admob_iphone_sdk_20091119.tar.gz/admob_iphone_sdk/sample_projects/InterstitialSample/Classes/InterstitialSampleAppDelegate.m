//
//  InterstitialSampleAppDelegate.m
//  InterstitialSample
//
//  Copyright AdMob 2009. All rights reserved.
//

#import "InterstitialSampleAppDelegate.h"
#import "InterstitialSampleViewController.h"
#import "AdMobInterstitialAd.h"

@interface InterstitialSampleAppDelegate()

- (void)finishApplicationInitialization;

@end


@implementation InterstitialSampleAppDelegate

@synthesize window;
@synthesize viewController;


- (void)applicationDidFinishLaunching:(UIApplication *)application 
{
  // Override point for customization after app launch
  
  // Request an interstitial at "Application Open" time.
  // optionally retain the returned AdMobInterstitialAd.
  [AdMobInterstitialAd requestInterstitialAt:AdMobInterstitialEventAppOpen 
                                    delegate:viewController 
                        interstitialDelegate:viewController];

  // Please note that while applicationDidFinishLaunching is still executing, 
  // the network calls for the AdMobInterstitialAd will will not start executing 
  // until the applicationDidFinishLaunching call returns.
  
  [window addSubview:viewController.view];
  [window makeKeyAndVisible];

  // we split the initialization process between applicationDidFinishLaunching and another
  // method to allow the network calls for the interstitial ad to start.
  [self performSelector:@selector(finishApplicationInitialization) withObject:nil afterDelay:0.1];
  
  // Depending on if there is an interstitial to show or not the next method
  // to be called will be one of:
  //   [viewController didReceiveInterstitial]
  //   [viewController didFailToReceiveInterstitial]

  // We have an internal timeout of approximately 5 seconds enforced
  // at the client level.  You should receive a callback before that
  // timeout, but if you do not, we will fail the request and continue
  // caching asset resources (less than 10k and not including a video)
  // if necessary in the background.  We recommend using the AdMob SDK's 
  // timeout mechanism.  If you choose to use an additional timeout mechanism, 
  // we have seen negative performance with timeout values below 5 seconds.
}

- (void)finishApplicationInitialization
{
  // finish any other initialization code here.
}


- (void)dealloc
{
  [viewController release];
  [window release];
  [super dealloc];
}


@end
