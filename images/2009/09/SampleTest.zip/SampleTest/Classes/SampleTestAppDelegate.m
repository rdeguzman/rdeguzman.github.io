//
//  SampleTestAppDelegate.m
//  SampleTest
//
//  Created by rupert on 7/09/09.
//  Copyright __MyCompanyName__ 2009. All rights reserved.
//

#import "SampleTestAppDelegate.h"

@implementation SampleTestAppDelegate

@synthesize window;


- (void)applicationDidFinishLaunching:(UIApplication *)application {    

    // Override point for customization after application launch
    [window makeKeyAndVisible];
}


- (void)dealloc {
    [window release];
    [super dealloc];
}


@end
