//
//  DrawMapAppDelegate.h
//  DrawMap
//
//  Created by rupert on 8/09/09.
//  Copyright __MyCompanyName__ 2009. All rights reserved.
//

#import <UIKit/UIKit.h>

@class DrawGeometryMapViewController;

@interface DrawMapAppDelegate : NSObject <UIApplicationDelegate> {
    UIWindow *window;
	DrawGeometryMapViewController *viewController;
	UINavigationController *navigationController;
}

@property (nonatomic, retain) IBOutlet UIWindow *window;
@property (nonatomic, retain) IBOutlet DrawGeometryMapViewController *viewController;

@end

