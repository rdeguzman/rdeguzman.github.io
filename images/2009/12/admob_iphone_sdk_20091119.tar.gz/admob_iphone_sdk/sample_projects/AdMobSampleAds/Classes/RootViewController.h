//
//  RootViewController.h
//  AdMobSampleAds
//
//  Created by Michael Ying on 6/2/09.
//  Copyright AdMob, Inc. 2009. All rights reserved.
//

@interface RootViewController : UITableViewController {
  NSMutableArray *menuList;
}

@end
