class CreateOriginalCategories < ActiveRecord::Migration
  def self.up
    create_table :original_categories, :force => true  do |t|
      t.string :cn_name
      t.string :en_name
      t.integer :original_category_level
      t.string :original_node_id
      t.integer :categ_id
      t.string :categ_node_id

      t.timestamps
    end
  end

  def self.down
    drop_table :original_categories
  end
end
