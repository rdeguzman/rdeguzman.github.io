/**
 * RootViewController.m
 * AdMob iPhone SDK publisher code.
 */

#import <UIKit/UIKit.h>
#import "AdMobDelegateProtocol.h"

@interface TableViewAdViewController : UITableViewController<AdMobDelegate> {
}

@end