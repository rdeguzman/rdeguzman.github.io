//
//  LinePolygonAnnotationView.m
//  testMapp
//
//  Created by Craig on 8/18/09.
//  Copyright Craig Spitzkoff 2009. All rights reserved.
//

#import "LinePolygonAnnotationView.h"
#import "GeometryAnnotation.h"

// this is an internally used view to LinePolygonAnnotationView. The LinePolygonAnnotationView needs a subview that does not get clipped to always
// be positioned at the full frame size and origin of the map. This way the view can be smaller than the line, but it
// always draws in the internal subview, which is the size of the map view. 
@interface LinePolygonAnnotationInternalView : UIView
{
	// line view which added this as a subview. 
	LinePolygonAnnotationView* _mainView;
}
@property (nonatomic, retain) LinePolygonAnnotationView* mainView;
@end

@implementation LinePolygonAnnotationInternalView

@synthesize mainView = _mainView;

-(id) init
{
	self = [super init];
	self.backgroundColor = [UIColor clearColor];
	self.clipsToBounds = NO;
	
	return self;
}


-(void) drawRect:(CGRect) rect
{
	GeometryAnnotation* myAnnotation = (GeometryAnnotation*)self.mainView.annotation;
	
	// only draw our lines if we're not int he moddie of a transition and we 
	// acutally have some points to draw. 
	if(!self.hidden && nil != myAnnotation.points && myAnnotation.points.count > 0)
	{
		CGContextRef context = UIGraphicsGetCurrentContext(); 
		
		// Drawing lines with a white stroke color
		CGContextSetRGBStrokeColor(context, 1.0, 1.0, 1.0, 1.0);
		
		// Draw them with a 2.0 stroke width so they are a bit more visible.
		CGContextSetLineWidth(context, 2.0);		
		
		if(myAnnotation.geometryType == kGeometryTypePolygon){
			CGContextSetRGBFillColor(context, 0.0, 0.0, 1.0, 1.0);
		}
		
		// Draw them with a 2.0 stroke width so they are a bit more visible.
		CGContextSetLineWidth(context, 2.0);
		
		for(int idx = 0; idx < myAnnotation.points.count; idx++)
		{
			CLLocation* location = [myAnnotation.points objectAtIndex:idx];
			CGPoint point = [self.mainView.mapView convertCoordinate:location.coordinate toPointToView:self];
			
			NSLog(@"Point: %lf, %lf", point.x, point.y);
			
			if(idx == 0)
			{
				// move to the first point
				CGContextMoveToPoint(context, point.x, point.y);
			}
			else
			{
				CGContextAddLineToPoint(context, point.x, point.y);
			}
		}
		
		if(myAnnotation.geometryType == kGeometryTypeLine){
			CGContextStrokePath(context);
		}
		else if(myAnnotation.geometryType == kGeometryTypePolygon){
			CGContextClosePath(context);
			
			CGContextDrawPath(context, kCGPathFillStroke);
		}
		
	}
	
	
}

-(void) dealloc
{
	self.mainView = nil;
	
	[super dealloc];
}
@end

@implementation LinePolygonAnnotationView

@synthesize mapView = _mapView;

- (id)initWithFrame:(CGRect)frame {
    if (self = [super initWithFrame:frame]) {
        
		self.backgroundColor = [UIColor clearColor];
		
		// do not clip the bounds. We need the LinePolygonAnnotationInternalView to be able to render the whole line/polygon, regardless of where the
		// actual annotation view is displayed. 
		self.clipsToBounds = NO;
		
		// create the internal line view that does the rendering of the line. 
		_internalView = [[LinePolygonAnnotationInternalView alloc] init];
		_internalView.mainView = self;
		
		[self addSubview:_internalView];
    }
    return self;
}

-(void) setMapView:(MKMapView*) mapView
{
	[_mapView release];
	_mapView = [mapView retain];
	
	[self regionChanged];
}

-(void) regionChanged
{
	NSLog(@"Region Changed");
	
	// move the internal line view. 
	CGPoint origin = CGPointMake(0, 0);
	origin = [_mapView convertPoint:origin toView:self];
	
	_internalView.frame = CGRectMake(origin.x, origin.y, _mapView.frame.size.width, _mapView.frame.size.height);
	[_internalView setNeedsDisplay];
	
}

- (void)dealloc 
{
	[_mapView release];
	[_internalView release];
	
    [super dealloc];
}


@end
