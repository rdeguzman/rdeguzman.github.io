//
//  DrawMapViewController.h
//  DrawMap
//
//  Created by rupert on 8/09/09.
//  Copyright __MyCompanyName__ 2009. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <MapKit/MapKit.h>
#import "Geometry.h"
#import "GeometryTouchView.h"
#import "LinePolygonAnnotationView.h"

@interface DrawMapViewController : UIViewController <MKMapViewDelegate>{
	UIBarButtonItem *mapBarButton;
	UIBarButtonItem *pointBarButton;
	UIBarButtonItem *lineBarButton;
	UIBarButtonItem *polygonBarButton;
	
	Geometry *geometry;
	GeometryTouchView *geometryTouchView;
	MKMapView *mapview;
	
	LinePolygonAnnotationView *currentAnnotationView;
}

- (void)mapBarButtonPressed;

- (void)pointBarButtonPressed;

- (void)lineBarButtonPressed;

- (void)polygonBarButtonPressed;

@end

