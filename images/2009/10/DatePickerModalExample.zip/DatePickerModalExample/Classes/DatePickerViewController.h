//
//  DatePickerViewController.h
//  DBYD
//
//  Created by rupert on 13/08/09.
//  Copyright 2009 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>

@protocol DatePickerViewControllerDelegate;

@interface DatePickerViewController : UIViewController {
	IBOutlet UIDatePicker *datePicker;
	id<DatePickerViewControllerDelegate> delegate;
}

@property (retain) IBOutlet UIDatePicker *datePicker;
@property (assign) id<DatePickerViewControllerDelegate> delegate;

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil;

- (IBAction)doneButtonPressed:(id)sender;
@end

@protocol DatePickerViewControllerDelegate <NSObject>

@optional
-(void)datePickerViewController:(DatePickerViewController *)controller didChooseDate:(NSString *)chosenDate;

@end
