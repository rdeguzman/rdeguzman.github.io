class PoiCategory < ActiveRecord::Base
end
