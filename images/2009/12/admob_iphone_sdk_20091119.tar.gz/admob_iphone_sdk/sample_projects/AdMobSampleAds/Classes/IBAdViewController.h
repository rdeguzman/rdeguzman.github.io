/**
 * IBAdViewController.h
 * AdMob iPhone SDK sample code.
 *
 */

#import <UIKit/UIKit.h>

@interface IBAdViewController : UIViewController {

}

@end