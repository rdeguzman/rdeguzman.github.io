class PoiApp < ActiveRecord::Base
end
