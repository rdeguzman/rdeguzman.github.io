//
//  AddressViewController.h
//  iDig
//
//  Created by rupert on 2/11/09.
//  Copyright 2009 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>


@interface AddressViewController : UIViewController {

}

- (IBAction)dismiss;

@end
