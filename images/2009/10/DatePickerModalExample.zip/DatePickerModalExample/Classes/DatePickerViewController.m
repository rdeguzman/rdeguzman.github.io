//
//  DatePickerViewController.m
//  DBYD
//
//  Created by rupert on 13/08/09.
//  Copyright 2009 __MyCompanyName__. All rights reserved.
//

#import "DatePickerViewController.h"

@implementation DatePickerViewController

@synthesize datePicker, delegate;

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil {
    if (self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil]) {
        // Custom initialization
		self.title = @"Date Picker";
    }
    return self;
}

- (void)viewDidLoad {
	NSLog(@"Date Picker. viewDidLoad");
    [super viewDidLoad];

	double days = 2.0f;
	datePicker.date = [NSDate dateWithTimeIntervalSinceNow:60.0f * 60.0f * 24.0f * days];
}


//-(void)datePickerViewController:(DatePickerViewController *)controller didChooseDate:(NSString *)chosenDate;

- (IBAction)doneButtonPressed:(id)sender
{
    if ([self.delegate respondsToSelector:@selector(datePickerViewController:didChooseDate:)]) {
		NSDateFormatter *dateFormatter = [[[NSDateFormatter alloc] init]  autorelease];
		[dateFormatter setDateStyle:NSDateFormatterMediumStyle];
		
		NSString *dateString = [dateFormatter stringFromDate:[datePicker date]];
		
        [self.delegate datePickerViewController:self didChooseDate:dateString];
    }
}

- (void)dealloc {
	[datePicker release];
    [super dealloc];
}

@end
