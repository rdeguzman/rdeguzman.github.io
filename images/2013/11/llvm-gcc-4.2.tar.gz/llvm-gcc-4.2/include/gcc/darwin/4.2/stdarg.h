/* This file is public domain.  */
#ifdef __MWERKS__
#include "mw_stdarg.h"
#else
#error "This header only supports __MWERKS__."
#endif
