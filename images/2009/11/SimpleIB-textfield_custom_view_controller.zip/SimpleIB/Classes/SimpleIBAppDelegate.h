//
//  SimpleIBAppDelegate.h
//  SimpleIB
//
//  Created by rupert on 2/11/09.
//  Copyright __MyCompanyName__ 2009. All rights reserved.
//

#import <UIKit/UIKit.h>

@class SimpleIBViewController;

@interface SimpleIBAppDelegate : NSObject <UIApplicationDelegate> {
    UIWindow *window;
    SimpleIBViewController *viewController;
}

@property (nonatomic, retain) IBOutlet UIWindow *window;
@property (nonatomic, retain) IBOutlet SimpleIBViewController *viewController;

@end

