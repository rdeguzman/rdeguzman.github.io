//
//  ConverterTest.h
//  SampleTest
//
//  Created by rupert on 7/09/09.
//  Copyright 2009 __MyCompanyName__. All rights reserved.
//

#import <SenTestingKit/SenTestingKit.h>


@interface ConverterTest : SenTestCase {

}

@end
