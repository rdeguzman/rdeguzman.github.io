//
//  DrawMapViewController.m
//  DrawMap
//
//  Created by rupert on 8/09/09.
//  Copyright __MyCompanyName__ 2009. All rights reserved.
//

#import "DrawMapViewController.h"
#import "LinePolygonAnnotationView.h"
#import "GeometryAnnotation.h"
#import "PointAnnotation.h"


@implementation DrawMapViewController

/*	State represents state of the map
 *	0 = map
 *	1 = point
 *	2 = line
 *	3 = polygon
 */

// The designated initializer. Override to perform setup that is required before the view is loaded.
- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil {
    if (self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil]) {
        // Custom initialization
		self.title = @"Map";
    }
    return self;
}


// Implement viewDidLoad to do additional setup after loading the view, typically from a nib.
- (void)viewDidLoad {
    [super viewDidLoad];
	
	currentAnnotationView = nil;
	
	//initialize mapview here
	mapview = [[MKMapView alloc] initWithFrame:CGRectMake(0.0f, 0.0f, 320.0f, 372.0f)];
	mapview.mapType = MKMapTypeSatellite;
	mapview.delegate = self;

	NSMutableArray *points = [[NSMutableArray alloc] initWithObjects:nil];
	geometry = [[Geometry alloc] initWithArray:points]; 
	[points release];
	
	//initialize geometryMapView which will catch touch Events
	geometryTouchView = [[GeometryTouchView alloc] initWithFrame:CGRectMake(0.0f, 0.0f, 320.0f, 372.0f)];
	geometryTouchView.backgroundColor = [UIColor clearColor];
	geometryTouchView.mapview = mapview;
	geometryTouchView.geometry = geometry;
	
	//[geometryMapView addSubview:mapview]; //replace this with [self.view addSubview:mapview];

	[self.view addSubview:mapview];
	
	[self.view addSubview:geometryTouchView];
	
	mapBarButton = [[UIBarButtonItem alloc] initWithTitle:@"MAP" style:UIBarButtonItemStyleBordered target:self action:@selector(mapBarButtonPressed)];
	pointBarButton = [[UIBarButtonItem alloc] initWithTitle:@"PT" style:UIBarButtonItemStyleBordered target:self action:@selector(pointBarButtonPressed)];
	lineBarButton = [[UIBarButtonItem alloc] initWithTitle:@"LN" style:UIBarButtonItemStyleBordered target:self action:@selector(lineBarButtonPressed)];
	polygonBarButton = [[UIBarButtonItem alloc] initWithTitle:@"PL" style:UIBarButtonItemStyleBordered target:self action:@selector(polygonBarButtonPressed)];
	
	NSArray *toolbarArray = [[NSArray alloc] initWithObjects:mapBarButton, pointBarButton, lineBarButton, polygonBarButton, nil];
	
	UIToolbar *toolbar = [[UIToolbar alloc] initWithFrame:CGRectMake(0.0f, 372.0f, 320.0f, 44.0f)];
	[toolbar setItems:toolbarArray];
	[toolbarArray release];
	
	[self.view addSubview:toolbar];
	[toolbar release];
		
	[self mapBarButtonPressed];
}


/*
// Override to allow orientations other than the default portrait orientation.
- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation {
    // Return YES for supported orientations
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}
*/

- (void)didReceiveMemoryWarning {
	// Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
	
	// Release any cached data, images, etc that aren't in use.
}

- (void)viewDidUnload {
	// Release any retained subviews of the main view.
	// e.g. self.myOutlet = nil;
}


- (void)mapBarButtonPressed{
	NSLog(@"mapBarButtonPressed");
	
	pointBarButton.enabled = YES;
	lineBarButton.enabled = YES;
	polygonBarButton.enabled = YES;
	
	mapBarButton.style = UIBarButtonItemStyleDone;
	geometryTouchView.hidden = YES;
}

- (void)showGeometryTouchViewForGeometry{
	if( geometry.pointsCount > 0){
		NSLog(@"resetting geometry.. deleting all points in geometry and annotation objects");
		NSArray *annotations = mapview.annotations;
		[mapview removeAnnotations:annotations];
		
		NSMutableArray *array = geometry.points;
		[array removeAllObjects];
	}
	
	pointBarButton.enabled = YES;
	lineBarButton.enabled = YES;
	polygonBarButton.enabled = YES;
	
	mapBarButton.style = UIBarButtonItemStyleBordered;
	geometryTouchView.hidden = NO;
}


- (void)pointBarButtonPressed{
	NSLog(@"pointBarButtonPressed");
	
	[self showGeometryTouchViewForGeometry];
	
	[geometry setGeometryType:kGeometryTypePoint];
	pointBarButton.enabled = NO;
}

- (void)lineBarButtonPressed{
	NSLog(@"lineBarButtonPressed");
	
	[self showGeometryTouchViewForGeometry];

	[geometry setGeometryType:kGeometryTypeLine];
	lineBarButton.enabled = NO;
}

- (void)polygonBarButtonPressed{
	NSLog(@"polygonBarButtonPressed");
	
	[self showGeometryTouchViewForGeometry];

	[geometry setGeometryType:kGeometryTypePolygon];
	polygonBarButton.enabled = NO;
}


- (void)mapView:(MKMapView *)mapView regionWillChangeAnimated:(BOOL)animated
{
	if(currentAnnotationView != nil){
		NSLog(@"regionWillChangeAnimated");
		
		currentAnnotationView.hidden = YES;
	}
}

- (void)mapView:(MKMapView *)mapView regionDidChangeAnimated:(BOOL)animated
{
	if(currentAnnotationView != nil){
		NSLog(@"regionDidChangeAnimated");
		
		currentAnnotationView.hidden = NO;
		[currentAnnotationView regionChanged];
	}
}

- (MKAnnotationView *)mapView:(MKMapView *)mapView viewForAnnotation:(id <MKAnnotation>)annotation{
	NSLog(@"viewForAnnotation");
	
	MKAnnotationView* annotationView = nil;
	
	if( [annotation isKindOfClass: [PointAnnotation class]] ){
		NSLog(@"its a pin class");
	}
	else if( [annotation isKindOfClass: [GeometryAnnotation class]] ){
		NSLog(@"its a line class");
		
		GeometryAnnotation *geometryAnnotation = (GeometryAnnotation *) annotation;

		LinePolygonAnnotationView * _annotationView = [[LinePolygonAnnotationView alloc] initWithFrame:CGRectMake(0.0f, 0.0f, mapView.frame.size.width, mapView.frame.size.height)];
		_annotationView.annotation = geometryAnnotation;
		_annotationView.mapView = mapView;
		
		currentAnnotationView = _annotationView;
		annotationView = _annotationView;
	}
	
	return annotationView;
}

- (void)dealloc {
	[mapBarButton release];
	[pointBarButton release];
	[lineBarButton release];
	[polygonBarButton release];
	
	[mapview release];
	[geometry release];
	[geometryTouchView release];
	
	if(currentAnnotationView != nil){
		[currentAnnotationView release];
	}

	
    [super dealloc];
}

@end