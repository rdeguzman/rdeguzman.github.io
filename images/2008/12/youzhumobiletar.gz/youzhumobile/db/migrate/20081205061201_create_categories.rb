class CreateCategories < ActiveRecord::Migration
  def self.up
    create_table :categories, :force => true  do |t|
      t.integer  :categ_level
      t.integer  :order_id
      t.string   :node_id
      t.boolean  :independent, :default => false
      t.string   :name_en
      t.string   :name_zh
      t.string   :name_fr
      t.string   :name_ru
      t.string   :name_es
      t.string   :name_de
      
      t.timestamps
    end
  end

  def self.down
    drop_table :categories
  end
end
