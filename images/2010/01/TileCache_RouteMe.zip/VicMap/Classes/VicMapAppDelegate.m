//
//  VicMapAppDelegate.m
//  VicMap
//
//  Created by rupert on 12/01/10.
//  Copyright __MyCompanyName__ 2010. All rights reserved.
//

#import "VicMapAppDelegate.h"

@implementation VicMapAppDelegate

@synthesize window;


- (void)applicationDidFinishLaunching:(UIApplication *)application {   
	//test hereinitialResolution = 2 * M_PI * 6378137 / [self tileSideLength];
	int s = 256;
	
	double a = 6378137;
	double b = 2;
	double c = (a * b * 3.14159265f)/s;
	
	NSLog(@"c: %f", c);
	
	
    viewController = [[VicMapViewController alloc] initWithNibName:@"VicMapViewController" bundle:nil];
	
    // Override point for customization after app launch    
    [window addSubview:viewController.view];
    [window makeKeyAndVisible];
}


- (void)dealloc {
    [viewController release];
    [window release];
    [super dealloc];
}


@end
