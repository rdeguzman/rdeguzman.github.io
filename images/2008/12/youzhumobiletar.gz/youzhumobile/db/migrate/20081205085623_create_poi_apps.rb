class CreatePoiApps < ActiveRecord::Migration
  def self.up
    create_table :poi_apps do |t|

      t.timestamps
    end
  end

  def self.down
    drop_table :poi_apps
  end
end
