//
//  MyRMSampleMapViewController.h
//  MyRMSampleMap
//
//  Created by rupert on 8/12/09.
//  Copyright __MyCompanyName__ 2009. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "RMMapView.h"

@interface MyRMSampleMapViewController : UIViewController {
	RMMapView *mapview;
}

@property(nonatomic, retain) RMMapView *mapview;

@end

