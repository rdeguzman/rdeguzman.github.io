//
//  MyRMSampleMapAppDelegate.h
//  MyRMSampleMap
//
//  Created by rupert on 8/12/09.
//  Copyright __MyCompanyName__ 2009. All rights reserved.
//

#import <UIKit/UIKit.h>

@class MyRMSampleMapViewController;

@interface MyRMSampleMapAppDelegate : NSObject <UIApplicationDelegate> {
    UIWindow *window;
    MyRMSampleMapViewController *viewController;
}

@property (nonatomic, retain) IBOutlet UIWindow *window;
@property (nonatomic, retain) IBOutlet MyRMSampleMapViewController *viewController;

@end

