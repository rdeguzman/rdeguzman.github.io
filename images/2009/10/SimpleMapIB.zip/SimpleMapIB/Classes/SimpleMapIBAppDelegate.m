//
//  SimpleMapIBAppDelegate.m
//  SimpleMapIB
//
//  Created by rupert on 29/10/09.
//  Copyright __MyCompanyName__ 2009. All rights reserved.
//

#import "SimpleMapIBAppDelegate.h"
#import "SimpleMapIBViewController.h"

@implementation SimpleMapIBAppDelegate

@synthesize window;
@synthesize viewController;


- (void)applicationDidFinishLaunching:(UIApplication *)application {    
    
    // Override point for customization after app launch    
    [window addSubview:viewController.view];
    [window makeKeyAndVisible];
}


- (void)dealloc {
    [viewController release];
    [window release];
    [super dealloc];
}


@end
