//
//  RouteMeSampleMapDBOfflineAppDelegate.h
//  RouteMeSampleMapDBOffline
//
//  Created by rupert on 22/12/09.
//  Copyright __MyCompanyName__ 2009. All rights reserved.
//

#import <UIKit/UIKit.h>

@class RouteMeSampleMapDBOfflineViewController;

@interface RouteMeSampleMapDBOfflineAppDelegate : NSObject <UIApplicationDelegate> {
    UIWindow *window;
    RouteMeSampleMapDBOfflineViewController *viewController;
}

@property (nonatomic, retain) IBOutlet UIWindow *window;
@property (nonatomic, retain) IBOutlet RouteMeSampleMapDBOfflineViewController *viewController;

- (NSString *)dbPath;

@end

