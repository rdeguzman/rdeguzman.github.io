//
//  SimpleIBViewController.h
//  SimpleIB
//
//  Created by rupert on 2/11/09.
//  Copyright __MyCompanyName__ 2009. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SimpleIBViewController : UIViewController <UITextFieldDelegate> {
	IBOutlet UIButton *buttonSearchAddress;
	IBOutlet UITextField *textFieldSearchAddress;
}

@property(nonatomic, retain) IBOutlet UIButton *buttonSearchAddress;
@property(nonatomic, retain) IBOutlet UITextField *textFieldSearchAddress;

-(IBAction)show;

@end

