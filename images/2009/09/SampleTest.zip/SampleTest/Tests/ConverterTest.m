//
//  ConverterTest.m
//  SampleTest
//
//  Created by rupert on 7/09/09.
//  Copyright 2009 __MyCompanyName__. All rights reserved.
//

#import "ConverterTest.h"
#import "Converter.h"

@implementation ConverterTest

- (void)testKilometersToMeters{
	int km = 1;
	Converter *converter = [[Converter alloc] init];
	int meters = [converter convertKilometersToMeters:km];
	STAssertTrue(meters == 1000, @"converting %d km to meters should equal 1000, instead received %d", km, meters);
}

@end
