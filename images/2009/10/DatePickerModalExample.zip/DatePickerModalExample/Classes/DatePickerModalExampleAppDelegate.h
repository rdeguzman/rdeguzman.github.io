//
//  DatePickerModalExampleAppDelegate.h
//  DatePickerModalExample
//
//  Created by rupert on 2/10/09.
//  Copyright __MyCompanyName__ 2009. All rights reserved.
//

#import <UIKit/UIKit.h>

@class DatePickerModalExampleViewController;

@interface DatePickerModalExampleAppDelegate : NSObject <UIApplicationDelegate> {
    UIWindow *window;
    DatePickerModalExampleViewController *viewController;
}

@property (nonatomic, retain) IBOutlet UIWindow *window;
@property (nonatomic, retain) IBOutlet DatePickerModalExampleViewController *viewController;

@end

