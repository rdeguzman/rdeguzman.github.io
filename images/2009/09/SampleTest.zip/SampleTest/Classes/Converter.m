//
//  Converter.m
//  SampleTest
//
//  Created by rupert on 7/09/09.
//  Copyright 2009 __MyCompanyName__. All rights reserved.
//

#import "Converter.h"

@implementation Converter

- (id)init{
	if(self = [super init]){
		
	}
	return self;
}

- (int)convertKilometersToMeters:(int)km{
	return km * 1000;
}

@end
