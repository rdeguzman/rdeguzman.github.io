//
//  VicMapAppDelegate.h
//  VicMap
//
//  Created by rupert on 12/01/10.
//  Copyright __MyCompanyName__ 2010. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "VicMapViewController.h"

@interface VicMapAppDelegate : NSObject <UIApplicationDelegate> {
    UIWindow *window;
    VicMapViewController *viewController;
}

@property (nonatomic, retain) IBOutlet UIWindow *window;

@end

