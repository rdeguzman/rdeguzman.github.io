//
//  DrawMapAppDelegate.m
//  DrawMap
//
//  Created by rupert on 8/09/09.
//  Copyright __MyCompanyName__ 2009. All rights reserved.
//

#import "DrawMapAppDelegate.h"

@implementation DrawMapAppDelegate

@synthesize window;
@synthesize viewController;


- (void)applicationDidFinishLaunching:(UIApplication *)application {    
    navigationController = [[UINavigationController alloc] initWithRootViewController:viewController];
    // Override point for customization after app launch    
    [window addSubview:navigationController.view];
    [window makeKeyAndVisible];
}


- (void)dealloc {
    [viewController release];
	[navigationController release];
    [window release];
    [super dealloc];
}


@end
