class CreateUsers < ActiveRecord::Migration
  def self.up
    create_table  :users, :force => true do |t|
      t.string    :name
      t.string    :email
      t.integer   :age
      t.string    :country_of_residence
      t.integer   :language_id, :default => 1
      t.string    :mobileno
      t.string    :gender      
      t.string    :salted_password
      t.string    :salt
      
      t.timestamps
    end
  end

  def self.down
    drop_table :users
  end
end
