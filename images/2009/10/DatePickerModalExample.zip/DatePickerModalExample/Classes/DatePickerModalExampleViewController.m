//
//  DatePickerModalExampleViewController.m
//  DatePickerModalExample
//
//  Created by rupert on 2/10/09.
//  Copyright __MyCompanyName__ 2009. All rights reserved.
//

#import "DatePickerModalExampleViewController.h"

@implementation DatePickerModalExampleViewController

@synthesize button;

/*
// The designated initializer. Override to perform setup that is required before the view is loaded.
- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil {
    if (self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil]) {
        // Custom initialization
    }
    return self;
}
*/

/*
// Implement loadView to create a view hierarchy programmatically, without using a nib.
- (void)loadView {
}
*/


/*
// Implement viewDidLoad to do additional setup after loading the view, typically from a nib.
- (void)viewDidLoad {
    [super viewDidLoad];
}
*/

-(IBAction)buttonPressed{
	NSLog(@"I was pressed");
	
	DatePickerViewController *datePickerViewController = [[DatePickerViewController alloc] initWithNibName:@"DatePickerViewController" bundle:nil];
	datePickerViewController.delegate = self;
	
	[self presentModalViewController:datePickerViewController animated:YES];
	
	[datePickerViewController release];	
}

-(void)datePickerViewController:(DatePickerViewController *)controller didChooseDate:(NSString *)chosenDate{
	NSLog(@"Chosen Date as String: %@", chosenDate );
	
	//do processing here... for example let's set the text of the button to the chosen date
	[button setTitle: chosenDate forState: UIControlStateNormal];
	
	[self dismissModalViewControllerAnimated:YES];
}

/*
// Override to allow orientations other than the default portrait orientation.
- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation {
    // Return YES for supported orientations
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}
*/

- (void)didReceiveMemoryWarning {
	// Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
	
	// Release any cached data, images, etc that aren't in use.
}

- (void)viewDidUnload {
	// Release any retained subviews of the main view.
	// e.g. self.myOutlet = nil;
}


- (void)dealloc {
	[button release];
    [super dealloc];
}

@end
