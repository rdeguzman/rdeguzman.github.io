//
//  VicMapViewController.h
//  VicMap
//
//  Created by rupert on 12/01/10.
//  Copyright __MyCompanyName__ 2010. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "RMMapView.h"

@interface VicMapViewController : UIViewController {
	RMMapView *mapview;
}

@property(nonatomic, retain) RMMapView *mapview;

@end