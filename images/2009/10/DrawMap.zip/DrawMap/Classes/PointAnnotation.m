//
//  Pin.m
//  DBYD
//
//  Created by rupert on 20/07/09.
//  Copyright 2009 __MyCompanyName__. All rights reserved.
//
//  If this implementation is to be modified, then it is better to subclass it.

#import "PointAnnotation.h"

@class PointAnnotation;

@implementation PointAnnotation

@synthesize coordinate, title, subTitle;

- (id)initWithCoordinate:(CLLocationCoordinate2D)c{
	if(self = [super init]){
		self.title = @"";
		self.subTitle = @"";
		coordinate = c;
		
		NSLog(@"Newly created pin at %f,%f", c.latitude, c.longitude);
	}
	return self;
}

- (CLLocationCoordinate2D)coordinate{
	return coordinate;
}

- (void)dealloc{
	[title release];
	[subTitle release];

	[super dealloc];
}


@end
