class OriginalCategory < ActiveRecord::Base
end
