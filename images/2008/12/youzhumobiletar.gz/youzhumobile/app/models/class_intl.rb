class ClassIntl < ActiveRecord::Base
end
