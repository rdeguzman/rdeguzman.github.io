//
//  RouteMeSampleMapDBOfflineViewController.m
//  RouteMeSampleMapDBOffline
//
//  Created by rupert on 22/12/09.
//  Copyright __MyCompanyName__ 2009. All rights reserved.
//

#import "RouteMeSampleMapDBOfflineViewController.h"
#import "RMDBMapSource.h"
#import "RMTileSource.h"
#import "RMMapContents.h"
#import "RouteMeSampleMapDBOfflineAppDelegate.h"
#import "RMMarkerManager.h"

@interface RouteMeSampleMapDBOfflineViewController(private)
- (CLLocationCoordinate2D)demoCoordinate;
@end

@implementation RouteMeSampleMapDBOfflineViewController

@synthesize mapview;

- (CLLocationCoordinate2D)demoCoordinate{
	CLLocationCoordinate2D demoCoordinate;
	
	demoCoordinate.latitude = 12.02; //Manila.db
	demoCoordinate.longitude = 121.74;

	return demoCoordinate;
}

- (void)viewWillAppear:(BOOL)animated{
	mapview = [[RMMapView alloc] initWithFrame:CGRectMake(0.0f, 0.0f, 320.0f, 460.0f)];
	[mapview setBackgroundColor:[UIColor whiteColor]];
	mapview.delegate = self;	

	id <RMTileSource> tileSource = [[[RMDBMapSource alloc] initWithPath:@"ph-1.0.0.db"] autorelease];
	
	RMMapContents *rmcontents = [[RMMapContents alloc] initWithView:mapview tilesource:tileSource]; 
	
	[rmcontents setTileSource:tileSource];
	//[rmcontents setMaxZoom:14.0f];
	//[rmcontents setMinZoom:13.0f];
	
	[rmcontents setZoom:6.0f];
	[rmcontents setMapCenter:[self demoCoordinate]];
	
	[self.view addSubview:mapview];	
	
}

- (void)didReceiveMemoryWarning {
	// Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
	
	// Release any cached data, images, etc that aren't in use.
}

- (void)viewDidUnload {
	// Release any retained subviews of the main view.
	// e.g. self.myOutlet = nil;
}


- (void)dealloc {
	[mapview dealloc];
	
    [super dealloc];
}

@end
