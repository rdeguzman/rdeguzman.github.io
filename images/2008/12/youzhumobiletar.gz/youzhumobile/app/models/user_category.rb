class UserCategory < ActiveRecord::Base
end
