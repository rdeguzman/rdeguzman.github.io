//
//  SimpleMapIBAppDelegate.h
//  SimpleMapIB
//
//  Created by rupert on 29/10/09.
//  Copyright __MyCompanyName__ 2009. All rights reserved.
//

#import <UIKit/UIKit.h>

@class SimpleMapIBViewController;

@interface SimpleMapIBAppDelegate : NSObject <UIApplicationDelegate> {
    UIWindow *window;
    SimpleMapIBViewController *viewController;
}

@property (nonatomic, retain) IBOutlet UIWindow *window;
@property (nonatomic, retain) IBOutlet SimpleMapIBViewController *viewController;

@end

