class CreatePoiCategories < ActiveRecord::Migration
  def self.up
    create_table :poi_categories, :force => true  do |t|
      t.integer :poi_app_id
      t.integer :original_class_id
      t.string  :original_node_id
      t.integer :categ_id
      t.string  :categ_node_id

      t.timestamps
    end
  end

  def self.down
    drop_table :poi_categories
  end
end
