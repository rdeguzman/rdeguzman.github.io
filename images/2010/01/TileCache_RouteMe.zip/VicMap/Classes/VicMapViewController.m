//
//  VicMapViewController.m
//  VicMap
//
//  Created by rupert on 12/01/10.
//  Copyright __MyCompanyName__ 2010. All rights reserved.
//

#import "VicMapViewController.h"
#import "RMGenericMercatorWMSSource.h"

//#define kWMSURL @"http://127.0.0.1/tilecache/tilecache.py?"
//#define kWMSURL @"http://127.0.0.1/cgi-bin/mapserv?"
//#define kWMSURL @"http://192.168.1.193:81/cgi-bin/mapserv.exe?"
#define kWMSURL @"http://192.168.1.193:81/tilecache/tilecache.py?"

@interface VicMapViewController(private)
- (CLLocationCoordinate2D)demoCoordinate;
- (void)showAlert:(NSString *)message title:title;
@end

@implementation VicMapViewController

@synthesize mapview;

// The designated initializer. Override to perform setup that is required before the view is loaded.
- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil {
    if (self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil]) {
        // Custom initialization
		
		//Testing for MAC:TileCache - not ok
		//NSArray *arrayValues = [[NSArray alloc] initWithObjects:@"mapserver_australia_3857", @"png", @"EPSG:3857",nil]; 
		
		//Testing for MAC:Mapserver - ok
		//NSArray *arrayValues = [[NSArray alloc] initWithObjects:@"/Users/rupert/projects/pelicancorp/DMOB/trunk/map/australia_3857.map", @"all", @"png", @"EPSG:3857",nil]; //for Mac
		
		
		//Testing for Windows:Mapserver - ok
		//NSArray *arrayValues = [[NSArray alloc] initWithObjects:@"E:\\RupertWork\\wwwroot\\map\\australia_3857.map", @"all", @"png", @"EPSG:3857",nil]; //for WIndows
		
		//Testing for Windows:TileCache - ?
		NSArray *arrayValues = [[NSArray alloc] initWithObjects:@"australia_3857", @"png", @"EPSG:3857",nil]; //for WIndows
		
		//TileCache URL Parameters:
		NSArray *arrayKeys = [[NSArray alloc] initWithObjects:@"LAYERS", @"FORMAT", @"SRS", nil];
		
		//Mapserver URL Parameters:
		//NSArray *arrayKeys = [[NSArray alloc] initWithObjects:@"MAP", @"LAYERS", @"FORMAT", @"SRS", nil];
		
		NSDictionary *wmsParameters = [[NSDictionary alloc] initWithObjects: arrayValues forKeys:arrayKeys ];
		[arrayValues release];
		[arrayKeys release];
		
		mapview = [[RMMapView alloc] initWithFrame:CGRectMake(0.0f, 0.0f, 320.0f, 460.0f)];
		[mapview setBackgroundColor:[UIColor whiteColor]];
		
		id <RMTileSource> tileSource;
		
		tileSource = [[[RMGenericMercatorWMSSource alloc] initWithBaseUrl:kWMSURL parameters:wmsParameters] autorelease];
		
		RMMapContents *rmcontents = [[RMMapContents alloc] initWithView:mapview tilesource:tileSource]; 
		[rmcontents setTileSource:tileSource];
		
		[rmcontents setZoom:10.0f];
		[rmcontents setMapCenter:[self demoCoordinate]];
		
		[self.view addSubview:mapview];

    }
    return self;
}

- (void)showAlert:(NSString *)message title:title{
	UIAlertView *errorAlertView = [[[UIAlertView alloc] initWithTitle:title message:message delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil] autorelease];
	[errorAlertView show];	
}

/*
// Implement loadView to create a view hierarchy programmatically, without using a nib.
- (void)loadView {
}
*/


// Implement viewDidLoad to do additional setup after loading the view, typically from a nib.
- (void)viewDidLoad {
    [super viewDidLoad];
	
	[self showAlert:@"Welcome to VicMaps-v1.\n Who needs Google when we can have our own maps. Using Mapserver, OpenLayers (for testing Mapserver), and TileCache for creating the tiles. We can get a 256x256 tile on our mobile device. If the map is slow, then TC is creating the image but once its created the iPhone just pulls the tile off from the webserver--similar to Google Tiles. On top of this, it has mobile caching capability. Details to be explained during a meeting. Note: Make sure you can access 192.168.1.193, this means WIFI(ON). So its local for the moment." title:@"Info"];
}


/*
// Override to allow orientations other than the default portrait orientation.
- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation {
    // Return YES for supported orientations
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}
*/

- (void)didReceiveMemoryWarning {
	// Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
	
	// Release any cached data, images, etc that aren't in use.
}

- (void)viewDidUnload {
	// Release any retained subviews of the main view.
	// e.g. self.myOutlet = nil;
}


- (void)dealloc {
    [super dealloc];
}

- (CLLocationCoordinate2D)demoCoordinate{
	CLLocationCoordinate2D demoCoordinate;
	
	demoCoordinate.latitude = -37.806530; //Rokeby Street
	demoCoordinate.longitude = 144.988032;
	
	//demoCoordinate.latitude = 61.7; //Alaska
	//demoCoordinate.longitude = -156.540;
	
	//demoCoordinate.latitude = 39.907; //Beijing
	//demoCoordinate.longitude = 116.391;
	
	//demoCoordinate.latitude = 49.5832; //test.db
	//demoCoordinate.longitude = 11.032;
	
	return demoCoordinate;
}

@end
