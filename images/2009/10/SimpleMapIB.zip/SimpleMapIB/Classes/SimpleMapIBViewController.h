//
//  SimpleMapIBViewController.h
//  SimpleMapIB
//
//  Created by rupert on 29/10/09.
//  Copyright __MyCompanyName__ 2009. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <MapKit/MapKit.h>

@interface SimpleMapIBViewController : UIViewController {
	IBOutlet MKMapView *mapview;
	IBOutlet UISegmentedControl *segmentedControlMapType;
}

@property(nonatomic, retain) IBOutlet MKMapView *mapview;
@property(nonatomic, retain) IBOutlet UISegmentedControl *segmentedControlMapType;

- (IBAction)changeMapType: (id)sender;

@end

